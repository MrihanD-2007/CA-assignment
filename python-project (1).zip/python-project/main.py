
def logical_left_shift(binary, positions):
    print(f"\nOriginal number: {binary}")
    result = binary

    for i in range(positions):
        result = result[1:] + '0'
        print(f"After left shift {i + 1}: {result}")

    return result


def logical_right_shift(binary, positions):
    print(f"\nOriginal number: {binary}")
    result = binary

    for i in range(positions):
        result = '0' + result[:-1]
        print(f"After right shift {i + 1}: {result}")

    return result


# a) Logical left shift by 3 positions
print("a) Logical Left Shift")
left_result = logical_left_shift("10110110", 3)
print("Final 8-bit result:", left_result)

# b) Logical right shift by 3 positions
print("\nb) Logical Right Shift")
right_result = logical_right_shift("11010100", 3)
print("Final 8-bit result:", right_result)
