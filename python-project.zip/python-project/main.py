
def to_8bit_twos_complement(n):
    """Convert a signed decimal number to 8-bit 2's complement."""
    return format(n & 0xFF, '08b')


def signed_value(binary):
    """Convert 8-bit 2's complement binary to signed decimal."""
    value = int(binary, 2)
    if value >= 128:
        value -= 256
    return value


def binary_addition(a, b):
    # Convert operands to 8-bit binary
    bin_a = to_8bit_twos_complement(a)
    bin_b = to_8bit_twos_complement(b)

    # Perform addition using 8-bit arithmetic
    full_sum = int(bin_a, 2) + int(bin_b, 2)
    result = format(full_sum & 0xFF, '08b')

    # Check signed arithmetic overflow
    overflow = (a >= 0 and b >= 0 and signed_value(result) < 0) or \
               (a < 0 and b < 0 and signed_value(result) >= 0)

    print(f"Operand A: {a:4d} = {bin_a}")
    print(f"Operand B: {b:4d} = {bin_b}")
    print(f"Addition : {bin_a} + {bin_b}")
    print(f"Result   : {result}")
    print(f"Decimal  : {signed_value(result)}")
    print("Overflow :", "Yes" if overflow else "No")
    print("-" * 45)


print("a) (120) + (+62)")
binary_addition(120, 62)

print("b) (-120) + (-62)")
binary_addition(-120, -62)
